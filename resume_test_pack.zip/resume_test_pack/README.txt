Resume test pack

10 fictional, selectable-text PDF resumes for recruiter-card and resume-upload testing. All identities and experience are synthetic; emails use example.com and phone numbers use reserved fictional numbers.

See test_cases.csv for the intended edge cases. Riley Chen deliberately has no email or phone. Morgan Davis has a two-page resume.

Suggested checks: upload each PDF, verify name and role extraction, check wrapping on the long-name profile, inspect missing-contact fallback, and confirm page 2 is processed.
